package project;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/ForgetpasswordAction")
public class Forgetpassword extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email=request.getParameter("email");
		String mobile_number=request.getParameter("mobile_number");
		String security_question=request.getParameter("security_question");
		String answer=request.getParameter("answer");
       String new_password=request.getParameter("password");
       
    
       int check=0;
       try{
    	   
    	   Connection con=ConnectionProvider.getCon();
    	   Statement st=con.createStatement();
    	   ResultSet rs=st.executeQuery("select * from users where email='"+email+"' and mobile_number='"+mobile_number+"' and security_question='"+security_question+"' and answer='"+answer+"'");
    	   while(rs.next())
    	   {
    		   check=1;
    		   st.executeUpdate("update users set password='"+new_password+"' where email='"+email+"'");

    	      
    		   response.sendRedirect("forgotPassword.jsp?msg=done");
    	   }
    	   if(check==0)
    	   {
    		   
    		   response.sendRedirect("forgotPassword.jsp?msg=invalid");
    		   
    	   }
       }
       catch(Exception e)
       {
    	   
    	   System.out.println(e);
       }
	}

}
