package project;
import java.sql.*;

public class ConnectionProvider {
    private static Connection con = null;

    static {
        try {
            Class.forName("org.postgresql.Driver"); // Load driver
            String url = "jdbc:postgresql://localhost:5432/Rohit"; 
            String user = "postgres";
            String password = "1234";
            con = DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            throw new RuntimeException("Database connection failed!", e);
        }
    }

    public static Connection getCon() {
        return con;
    }
}
