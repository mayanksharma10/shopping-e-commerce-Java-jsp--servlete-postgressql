package project;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/admin/AddNewProductAction")
public class AddNewProductAction extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		String name=request.getParameter("name");
		String category=request.getParameter("category");
		String price=request.getParameter("price");
		String active=request.getParameter("active");

        response.setContentType("text/html");
		  PrintWriter out = response.getWriter();
			
		try(Connection con=ConnectionProvider.getCon())
		{

			 PreparedStatement ps = con.prepareStatement(
		                "INSERT INTO product(id, name, category, price, active) VALUES (?, ?, ?, ?, ?)"
		            );
				
			 ps.setInt(1, Integer.parseInt(id)); 
		   ps.setString(2, name);
		   ps.setString(3, category);
		   ps.setDouble(4, Double.parseDouble(price));

		   ps.setString(5, active);
		   
		ps.executeUpdate();
		System.out.println("okkkk");
		response.sendRedirect(request.getContextPath() + "/admin/addNewProduct.jsp?msg=done");

		//response.sendRedirect("addNewProduct.jsp?msg=done");
		RequestDispatcher rd = request.getRequestDispatcher("/admin/addNewProduct.jsp");
        rd.include(request, response);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//response.sendRedirect("addNewProduct.jsp?msg=wrong");
			response.sendRedirect(request.getContextPath() + "/admin/addNewProduct.jsp?msg=done");

			RequestDispatcher rd = request.getRequestDispatcher("/admin/addNewProduct.jsp");
            rd.include(request, response);
		}
	}

}
