package project;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/LoginAction")
public class Login extends HttpServlet {
	
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		if("admin@gmail.com".equals(email)&&"admin".equals(password))
		{
			HttpSession session = request.getSession();
            session.setAttribute("email", email);
            response.sendRedirect("admin/adminHome.jsp");
            
		}
		else
		{
		    try {
		        Connection con = ConnectionProvider.getCon();
		        Statement st = con.createStatement();
		        ResultSet rs = st.executeQuery("select * from users where email='" + email + "' and password='" + password + "'");
		        
		        boolean userFound = false;
		        while (rs.next()) {
		            userFound = true;
		            HttpSession session = request.getSession();
		            session.setAttribute("email", email);
		            response.sendRedirect("home.jsp");
		            return; // Stop execution after redirect
		        }
		        
		        if (!userFound) {
		            response.sendRedirect("login.jsp?msg=notexist");
		            return;
		        }
		    } catch (Exception e) {
		        e.printStackTrace();
		        response.sendRedirect("login.jsp?msg=invalid");
		    }
		}
	}
}