package project;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SignupAction")
public class Signup extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String mobile_number = request.getParameter("mobile_number");
        String security_question = request.getParameter("security_question");
        String answer = request.getParameter("answer");
        String password = request.getParameter("password");

        String address = "";
        String city = "";
        String state = "";
        String country = "";

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try (Connection con = ConnectionProvider.getCon())
        {
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO users(name, email, mobile_number, security_question, answer, password, address, city, state, country) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            );

            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, mobile_number);
            ps.setString(4, security_question);
            ps.setString(5, answer);
            ps.setString(6, password);
            ps.setString(7, address);
            ps.setString(8, city);
            ps.setString(9, state);
            ps.setString(10, country);

            int count = ps.executeUpdate();
            if (count > 0) {
                out.println("<h3 style='color:green'>User registered successfully</h3>");
                response.sendRedirect("signup.jsp?msg=valid");
                RequestDispatcher rd = request.getRequestDispatcher("/signup.jsp");
                rd.include(request, response);
            } else {
                out.println("<h3 style='color:red'>User not registered due to some error</h3>");
                response.sendRedirect("signup.jsp?msg=invalid");
            }
            RequestDispatcher rd = request.getRequestDispatcher("/signup.jsp");
            rd.include(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            out.println("<h3 style='color:red'>User not registered due to an error: " + e.getMessage() + "</h3>");
            response.sendRedirect("signup.jsp?msg=invalid");
            RequestDispatcher rd = request.getRequestDispatcher("/signup.jsp");
            rd.include(request, response);
        }
    }
}
